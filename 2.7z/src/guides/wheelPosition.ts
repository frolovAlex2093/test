import { IDict } from '../pages/Third';

export const wheelPosition: IDict = {
  справа: '10',
  слева: '20',
  посередине: '30'
};
