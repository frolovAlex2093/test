import { IDict } from '../pages/Third';

export const categoryId: IDict = {
  'категория B': 'B',
  'категория C': 'C',
  'категория D': 'D',
  'категория E': 'E',
  'категория F': 'F',
  прицеп: 'R',
  'категория AI': 'AI',
  'категория AII': 'AII',
  'категория AIV': 'AIV',
  'категория AIII': 'AIII'
};
