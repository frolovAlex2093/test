import { IDict } from '../pages/Third';

export const steeringType: IDict = {
  справа: '10',
  слева: '20',
  посередине: '30'
};
