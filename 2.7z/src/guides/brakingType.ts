import { IDict } from '../pages/Third';

export const brakingType: IDict = {
  Рабочая: '01',
  Запасная: '02',
  Стояночная: '03',
  'Вспомогательная (износостойкая)': '04'
};
